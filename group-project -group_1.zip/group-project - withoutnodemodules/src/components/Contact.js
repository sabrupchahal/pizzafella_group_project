import React from 'react';
import NavBar from './Navbar';
import Footer from './Footer';

const Contact = () => {
  return (
    <>
      <NavBar />
     

      <Footer />
    </>
  );
}

export default Contact;
